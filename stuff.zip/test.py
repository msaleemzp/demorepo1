import random

print("asd")
